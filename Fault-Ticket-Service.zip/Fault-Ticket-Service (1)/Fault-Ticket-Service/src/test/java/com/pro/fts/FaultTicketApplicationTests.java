package com.pro.fts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaultTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
