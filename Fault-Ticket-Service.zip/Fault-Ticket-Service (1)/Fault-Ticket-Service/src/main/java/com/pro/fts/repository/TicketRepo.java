package com.pro.fts.repository;

import com.pro.fts.entity.FaultTicket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TicketRepo extends JpaRepository<FaultTicket, Integer> {

    List<FaultTicket> findByType(String type);

    List<FaultTicket> findByStatus(String status);

    List<FaultTicket> findByCreatedOnBetween(LocalDate startDate, LocalDate endDate);

    @Query("SELECT t FROM FaultTicket t WHERE (:type is null OR t.type = :type) AND (:status is null OR t.status = :status) AND (t.createdOn BETWEEN :startDate AND :endDate)")
    List<FaultTicket> findByTypeAndStatusAndCreatedOnBetween(@Param("type") String type, @Param("status") String status,
                                                             @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}

