package com.pro.fts.controller;

import com.pro.fts.entity.FaultTicket;
import com.pro.fts.entity.PageResponse;
import com.pro.fts.service.FaultTicketService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


@RestController
@RequestMapping("/fault-ticket")
public class FaultTicketController {

    @Autowired
    private FaultTicketService faultTicketService;

    // Save operation
    @PostMapping("/tickets")
    public ResponseEntity<FaultTicket> createFaultTicket(@Valid @RequestBody FaultTicket faultTicket) {
        return new ResponseEntity<>(faultTicketService.createFaultTicket(faultTicket), HttpStatus.CREATED);
    }

    // Read operation
    @GetMapping("/tickets")
    public ResponseEntity<PageResponse<FaultTicket>> getFaultTicketList(Pageable pageable) {
        return new ResponseEntity<>(faultTicketService.getFaultTicketList(pageable), HttpStatus.OK);
    }

    // Update operation
    @PutMapping("/tickets/{ticketId}")
    public ResponseEntity<FaultTicket> updateFaultTicket(@Valid @RequestBody FaultTicket faultTicket,
                                                         @PathVariable("ticketId") Integer ticketId) {
        return new ResponseEntity<FaultTicket>(faultTicketService.updateFaultTicket(faultTicket, ticketId),
                HttpStatus.OK);
    }

    // Delete operations
    @DeleteMapping("/tickets/{ticketId}")
    public ResponseEntity<String> deleteFaultTicketById(@PathVariable("ticketId") Integer ticketId) {
        String msg = faultTicketService.deleteFaultTicketById(ticketId);
        return new ResponseEntity<String>(msg, HttpStatus.OK);
    }

// // Get By Type
// @ResponseBody
// @GetMapping("/tickets/byType")
// public ResponseEntity<List<FaultTicket>> viewByType(@RequestParam String type, @RequestParam String status) {
// List<FaultTicket> tickets = faultTicketService.viewByType(type);
// List<FaultTicket> tickets = faultTicketService.viewByStatus(status);

// Collections.sort(tickets, Comparator.comparing(FaultTicket::getTicketId).reversed());
// return new ResponseEntity<>(tickets, HttpStatus.OK);
// }

// // Get By Type
// @ResponseBody
// @GetMapping("/tickets/byType")
// public ResponseEntity<List<FaultTicket>> viewByType(@RequestParam String type) {
// List<FaultTicket> tickets = faultTicketService.viewByType(type);
// Collections.sort(tickets, Comparator.comparing(FaultTicket::getTicketId).reversed());
// return new ResponseEntity<>(tickets, HttpStatus.OK);
// }

    // Get By Status
//    @ResponseBody
//    @GetMapping("/tickets/byStatus")
//    public ResponseEntity<List<FaultTicket>> viewByStatus(@RequestParam String status) {
//        List<FaultTicket> tickets = faultTicketService.viewByStatus(status);
//        Collections.sort(tickets, Comparator.comparing(FaultTicket::getTicketId).reversed());
//        return new ResponseEntity<>(tickets, HttpStatus.OK);
//    }

    // Get by date range
//    @GetMapping("/tickets/date") // ?startDate=2023-01-01&endDate=2023-02-02
//    public ResponseEntity<List<FaultTicket>> getTicketsByDateRange(
//            @RequestParam("startDate") @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate startDate,
//            @RequestParam("endDate") @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate endDate) {
//
//        List<FaultTicket> tickets = faultTicketService.getTicketsByDateRange(startDate, endDate);
//        Collections.sort(tickets, Comparator.comparing(FaultTicket::getTicketId).reversed());
//        return new ResponseEntity<>(tickets, HttpStatus.OK);
//    }

    @GetMapping("/tickets/by")
    public ResponseEntity<List<FaultTicket>> getTicketsByTypeStatusAndDateRange(
            @RequestParam(required = false) String type, @RequestParam(required = false) String status,
            @RequestParam(required = false) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate endDate) {
        List<FaultTicket> tickets = faultTicketService.getTicketsByTypeStatusAndDateRange(type, status, startDate,
                endDate);
        Collections.sort(tickets, Comparator.comparing(FaultTicket::getTicketId).reversed());
        return new ResponseEntity<>(tickets, HttpStatus.OK);
    }

}