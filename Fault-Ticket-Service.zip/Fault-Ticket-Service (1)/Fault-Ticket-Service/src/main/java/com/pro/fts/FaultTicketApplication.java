package com.pro.fts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaultTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaultTicketApplication.class, args);
		System.out.println("-----*****FAULT-TICKET-APPLICATION RUNNING*****-----");
		System.out.println(" Date - 27-04-2023 | By - Mohit Arun Rajguru(1249983)");
	}

}
